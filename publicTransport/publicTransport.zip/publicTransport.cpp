﻿#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <forward_list>
#include <sstream>
#include <fstream>

#include "Bus.h"
#include "BusHasher.h"
#include "Edge.h"
#include "Station.h"
#include "Instrument.h"

using namespace std;

using AdjacencyList = unordered_set<Edge, EdgeHasher>;
using Graph = unordered_map<unsigned int, AdjacencyList>;
using Buses = unordered_set<Bus, BusHasher>;

void printGraph(const Graph& graph)
{
    for (const pair<unsigned int, AdjacencyList>& p : graph)
    {
        cout << "[" << p.first << "]";

        if (!p.second.empty())
        {
            cout << ": ";
            for (AdjacencyList::const_iterator it = p.second.begin(); it != p.second.end(); ++it)
            {
                Station adjacentStation = it->toStation;
                cout << "->";
                adjacentStation.print();
                cout << "(" << it->weight << ")";
            }
        }

        cout << endl;
    }
}

Edge getEdgeFromAdjacencyListByNumber(const AdjacencyList& adj, int number)
{
    for (const Edge& edge : adj)
    {
        if (edge.toStation.s_nr == number)
        {
            return edge;
        }
    }
}

void getAllPossiblePathsUtil(const Graph& graph, unsigned int fromStationNr, unsigned int toStationNr, vector<bool>& visited, vector<unsigned int>& path, unsigned int& pathIndex, std::vector<std::vector<int>>& routes)
{
    visited[fromStationNr] = true;
    path[pathIndex] = fromStationNr;
    pathIndex++;

    if (fromStationNr == toStationNr)
    {
        std::vector<int> route;
        for (size_t i{0}; i < pathIndex ;++i)
        {
            route.push_back(path[i]);
        }
        routes.push_back(route);
    }
    else
    {
            for (AdjacencyList::const_iterator it = graph.at(fromStationNr).begin(); it != graph.at(fromStationNr).end(); ++it)
            {
                Station adjacentStation = it->toStation;
                unsigned int adjacentStationNr = adjacentStation.s_nr;
                if (!visited[adjacentStationNr])
                {
                    getAllPossiblePathsUtil(graph, adjacentStationNr, toStationNr, visited, path, pathIndex, routes);
                }
            }
    }

    --pathIndex;
    visited[fromStationNr] = false;
}

std::vector<std::vector<int>> getAllPossiblePaths(const Graph& graph, unsigned int fromStationNr, unsigned int toStationNr)
{
    if (graph.find(fromStationNr) == graph.end())
    {
        throw std::exception("No station with such number found in graph! [fromStationNr]");
    }

    if (graph.find(toStationNr) == graph.end())
    {
        throw std::exception("No station with such number found in graph! [toStationNr]");
    }

    vector<bool> visited;
    visited.resize(graph.size());

    for (size_t i{ 0 }; i < visited.size(); ++i)
    {
        visited[i] = false;
    }

    vector<unsigned int> path;
    path.resize(graph.size());
    unsigned int path_index = 0;

    std::vector<std::vector<int>> result;

    getAllPossiblePathsUtil(graph, fromStationNr, toStationNr, visited, path, path_index, result);

    return result;
}

int calculateWeightOfPath(const Graph& g, const std::vector<int>& path)
{
    int accumulatedWeight{0};

    for (size_t i{0}; i < path.size() - 1; ++i)
    {
        int currentStationNr = path[i];
        int nextStationNr = path[i + 1];
        Edge next = getEdgeFromAdjacencyListByNumber(g.at(currentStationNr), nextStationNr);
        next.print(); std::cout << std::endl;
        accumulatedWeight += next.weight;
    }

    return accumulatedWeight;
}

using choicePair = pair<const unsigned int&, const unsigned int&>;

int main()
{
    try 
    {
        string filenameStations, filenameTimetable;
        filenameStations = "Stations.txt";
        filenameTimetable = "Timetable.txt";
        FileManager fmanager = FileManager(filenameStations, filenameTimetable);
        Graph g = fmanager.readGraph();
        Buses buses = fmanager.readBuses();
        printGraph(g);
        vector<vector<int>> allPossibleRoutes = getAllPossiblePaths(g, 8, 14);

        size_t i{ 1 };
        for (vector<int> route : allPossibleRoutes)
        {   
            std::cout << "Route [" << i << "]: ";
            for (int a : route)
            {
                std::cout << a << " ";
            }
            std::cout << "costs " << calculateWeightOfPath(g, route) <<  std::endl;
            ++i;
        }

        for (const Bus& bus : buses)
        {
            bus.print();
        }

    }
    catch (const std::exception& ex) 
    {
        cerr << ex.what() << endl;
    }

    const MenuItem* chosenAction;
    const MenuItem* chosenObject;
    
    string      stationsFilename    = "Stations.txt";
    string      timetableFilename   = "Timetable.txt";
    FileManager fmanager = FileManager(stationsFilename, timetableFilename);
    Instrument  instrument = Instrument(fmanager);

    while (true)
    {
        try
        {
            instrument.display(instrument.mainMenu);
            chosenAction = instrument.getChoice(instrument.mainMenu);
            string lastMainMenuItemNumber = instrument.mainMenu.back()->getNumber();
            if (chosenAction->match(lastMainMenuItemNumber))
                break;

            system("CLS");

            instrument.display(instrument.objectMenu);
            chosenObject = instrument.getChoice(instrument.objectMenu);
            string lastObjectMenuItemNumber = instrument.objectMenu.back()->getNumber();
            if (chosenObject->match(lastObjectMenuItemNumber))
            {
                system("CLS");
                continue;
            }

            unsigned int choice = stoi(chosenAction->getNumber()) * 10 + stoi(chosenObject->getNumber());

            switch (choice)
            {
            case 11:
                instrument.addStation();
                break;
            case 12:
                instrument.addRoute();
                break;
            case 13:
                instrument.addLine();
                break;
            case 21:
                instrument.removeStation();
                break;
            case 22:
                instrument.removeRoute();
                break;
            case 23:
                instrument.removeLine();
                break;
            default:
                throw exception("Case unhandled! Implement missing logic!");
            }

        }
        catch (std::exception& e)
        {
            cout << e.what() << endl;
        }
    }

    return 0;
 }